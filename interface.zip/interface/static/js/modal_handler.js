/* ===========================================================
   modal_handler.js — FINAL PERSISTENT VERSION
   -----------------------------------------------------------
   Keeps modal visible until user clicks the close (×) button.
   =========================================================== */

function showModal(message) {
  const modal = document.getElementById("modal");
  const modalText = document.getElementById("modal-text");

  if (!modal || !modalText) {
    console.warn("[Modal] Missing modal or modal-text element.");
    alert(message);
    return;
  }

  // Inject response (HTML supported)
  modalText.innerHTML = message;

  // Display and fix visibility
  modal.style.display = "flex";
  modal.classList.add("visible");

  // 🚫 REMOVE ANY OLD auto-close timers if present
  if (window.__modalTimeout) {
    clearTimeout(window.__modalTimeout);
    window.__modalTimeout = null;
  }
}

function closeModal() {
  const modal = document.getElementById("modal");
  if (!modal) return;
  modal.style.display = "none";
  modal.classList.remove("visible");
}

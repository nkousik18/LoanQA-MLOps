/* ===========================================================
   selection_handler.js
   -----------------------------------------------------------
   Detects text selection and connects toolbar buttons to
   backend LLM endpoints.
   =========================================================== */

let selectedText = "";

// Detect text selection
document.addEventListener("mouseup", () => {
  const selection = window.getSelection().toString().trim();
  const toolbar = document.getElementById("toolbar");

  if (selection.length > 0) {
    selectedText = selection;
    toolbar.style.display = "flex";
  } else {
    toolbar.style.display = "none";
  }
});

// Attach event listeners to buttons
document.getElementById("summary-btn").addEventListener("click", async () => {
  if (!selectedText) return showModal("⚠️ Please select some text first.");
  showModal("⏳ Generating summary...");
  const result = await callLLM("summary", selectedText);
  if (result && result.summary) showModal(`<b>Summary:</b><br>${result.summary}`);
});

document.getElementById("translate-btn").addEventListener("click", async () => {
  if (!selectedText) return showModal("⚠️ Please select some text first.");
  const lang = prompt("Enter target language (e.g., 'fr', 'es', 'hi'):", "fr");
  if (!lang) return;
  showModal(`⏳ Translating to ${lang.toUpperCase()}...`);
  const result = await callLLM("translate", selectedText, lang);
  if (result && result.translation)
    showModal(`<b>Translation (${lang.toUpperCase()}):</b><br>${result.translation}`);
});

document.getElementById("explain-btn").addEventListener("click", async () => {
  if (!selectedText) return showModal("⚠️ Please select some text first.");
  showModal("⏳ Generating explanation...");
  const result = await callLLM("explain", selectedText);
  if (result && result.explanation)
    showModal(`<b>Explanation:</b><br>${result.explanation}`);
});

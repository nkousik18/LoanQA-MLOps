/* ===========================================================
   api_calls.js
   -----------------------------------------------------------
   Handles API requests to Flask endpoints for Summary,
   Translation, and Explanation.
   =========================================================== */

const BASE_URL = "http://127.0.0.1:8000/api";

/**
 * Generic POST request handler for LLM endpoints.
 * @param {string} endpoint - "summary", "translate", or "explain"
 * @param {string} text - The selected text
 * @param {string} [lang] - Target language for translation
 */
async function callLLM(endpoint, text, lang = "en") {
  try {
    const payload =
      endpoint === "translate" ? { text: text, lang: lang } : { text: text };

    const response = await fetch(`${BASE_URL}/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) throw new Error(`Request failed: ${response.status}`);

    const data = await response.json();
    console.log(`[API] /${endpoint} response:`, data);

    // ✅ Show response result in modal
    if (data.translation) showModal(`🌍 Translated Text:\n${data.translation}`);
    else if (data.summary) showModal(`🧾 Summary:\n${data.summary}`);
    else if (data.explanation) showModal(`💡 Explanation:\n${data.explanation}`);
    else if (data.message) showModal(data.message);
    else showModal(`✅ Success but no readable output returned.`);

    return data;

  } catch (error) {
    console.error(`[API Error] ${endpoint}:`, error);
    showModal(`❌ ${endpoint.toUpperCase()} failed:\n${error.message}`);
    return null;
  }
}

/**
 * Simple modal display handler.
 */
function showModal(message) {
  const modal = document.getElementById("modal");
  const modalText = document.getElementById("modal-text");

  if (!modal || !modalText) {
    console.warn("⚠️ Modal not found in HTML.");
    alert(message);
    return;
  }

  modalText.textContent = message;
  modal.style.display = "flex";
  modal.classList.add("visible");
  modal.classList.remove("hidden");

  // Auto-hide after 6 seconds
  setTimeout(() => {
    modal.classList.remove("visible");
    modal.classList.add("hidden");
    modal.style.display = "none";
  }, 6000);
}

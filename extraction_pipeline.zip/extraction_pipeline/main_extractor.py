# extraction_pipeline/main_extractor.py

import os
from extraction_pipeline.extractor_core import extract_text
from extraction_pipeline.utils import save_text, list_files

def process_single_file(file_path: str):
    """
    Process a single document using extractor_core.
    Extract text and save to a unified directory: data/clean_texts.
    """
    print(f"[INFO] Processing single file: {file_path}")
    extracted_text = extract_text(file_path)

    # ✅ Always save extracted text to data/clean_texts
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    output_dir = os.path.join(project_root, "data", "clean_texts")
    os.makedirs(output_dir, exist_ok=True)

    out_path = save_text(extracted_text, output_dir, file_path)
    print(f"[✅] Extracted text saved to: {out_path}")

    return out_path



def run_extraction_pipeline(data_dir: str):
    """
    Batch process all documents in the given directory.
    """
    print(f"[INFO] Running extraction pipeline on: {data_dir}")
    files = list_files(data_dir)
    if not files:
        print("⚠️ No files found for extraction.")
        return

    for file_path in files:
        process_single_file(file_path)

    print("[✅] All documents processed successfully.")

def main(data_dir: str):
    """Alias for backward compatibility."""
    return run_extraction_pipeline(data_dir)

